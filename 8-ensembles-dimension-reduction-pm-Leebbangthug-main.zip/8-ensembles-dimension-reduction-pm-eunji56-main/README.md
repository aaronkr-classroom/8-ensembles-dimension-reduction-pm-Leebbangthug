[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=16948239)
# 8-ensemble-dims

IPYNB notebooks for UT Data Science (8주차)

1. 7장 - 앙상블 학습과 랜덤 포레스트
2. 8장 - 차원 축소
